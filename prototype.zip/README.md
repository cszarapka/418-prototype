# 418-prototype
Web prototype of the "nook" social media designed for EECE 418

## Instructions
Open `home_page.html` in your browser. Explore!

